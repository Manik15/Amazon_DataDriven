package com.amazon.practise;

import java.util.HashMap;
import java.util.Map;

public class testMap {
public static void main(String[] args) {
	Map<String, String> map=new HashMap<String, String>();
	map.put("HeaderValue", "Row Value");
	
	System.out.println("hello");
}
}
