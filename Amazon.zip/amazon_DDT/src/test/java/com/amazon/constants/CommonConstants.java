package com.amazon.constants;

public class CommonConstants {
public final static String USERNAME="userName";
public final static String PASSWORD="Password";
public final static String PRODNAME="Product";
public static final String MAX_PRICE ="Max Price";
public static final String MIN_PRICE = "Min Price";

public static final String LOCATION = "location";
public static final String QUANTITY = "Quantity";
public static final String OPERATING_SYS = "Os";
public static final String NUM = "num";









}
