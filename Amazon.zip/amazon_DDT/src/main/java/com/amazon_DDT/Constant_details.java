package com.amazon_DDT;

public class Constant_details {

	
	public static final String path="c:\\";
	
	public static final String excelName="TestData.xslx";
	
	public static final String URL= "https://www.amazon.co.in";
}
